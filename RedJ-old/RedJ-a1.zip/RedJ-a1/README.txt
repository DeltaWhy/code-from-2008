To install, just extract the zip file.

You will need to point RedJ to your JDK bin and your
jEdit directory. Optionally, you can point it to
your BlueJ executable to easily launch BlueJ. If the
settings window does not pop up, download setup.jar
separately and run it.

An installation of jEdit with an appropriate config
is included. If you already have jEdit, be aware that
RedJ will use its own jEdit config at "jEdit/.jedit".
If you want to use your existing settings, you need to
copy or link them here.
